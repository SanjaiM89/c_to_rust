// Translated automatically by c_to_rust converter
#![allow(unused, dead_code)]
use std::fs::File;
use std::io::{BufRead, BufReader, Read};
use std::path::Path;

/// Options configuring the INI parser.
#[derive(Debug, Clone)]
pub struct IniConfig {
    pub allow_multiline: bool,
    pub allow_inline_comments: bool,
    pub inline_comment_prefixes: &'static [char],
    pub start_comment_prefixes: &'static [char],
    pub stop_on_first_error: bool,
    pub allow_no_value: bool,
    pub call_handler_on_new_section: bool,
}

impl Default for IniConfig {
    fn default() -> Self {
        Self {
            allow_multiline: true,
            allow_inline_comments: true,
            inline_comment_prefixes: &[';', '#'],
            start_comment_prefixes: &[';', '#'],
            stop_on_first_error: false,
            allow_no_value: false,
            call_handler_on_new_section: false,
        }
    }
}

/// Parse INI content from a reader using default configuration.
pub fn parse_stream<R, F>(reader: R, handler: F) -> Result<(), i32>
where
    R: Read,
    F: FnMut(&str, Option<&str>, Option<&str>, i32) -> bool,
{
    parse_stream_config(reader, handler, &IniConfig::default())
}

/// Parse an INI string slice using default configuration.
pub fn parse_string<F>(content: &str, handler: F) -> Result<(), i32>
where
    F: FnMut(&str, Option<&str>, Option<&str>, i32) -> bool,
{
    parse_stream(content.as_bytes(), handler)
}

/// Parse an INI file at `path` using default configuration.
pub fn parse_file<P, F>(path: P, handler: F) -> Result<(), i32>
where
    P: AsRef<Path>,
    F: FnMut(&str, Option<&str>, Option<&str>, i32) -> bool,
{
    let file = File::open(path).map_err(|_| -1)?;
    parse_stream(file, handler)
}

/// Parse INI content from a reader with custom `IniConfig`.
pub fn parse_stream_config<R, F>(reader: R, mut handler: F, config: &IniConfig) -> Result<(), i32>
where
    R: Read,
    F: FnMut(&str, Option<&str>, Option<&str>, i32) -> bool,
{
    let mut buf_reader = BufReader::new(reader);
    let mut line_buf = String::new();
    let mut section = String::new();
    let mut prev_name = String::new();
    let mut lineno = 0;
    let mut error = 0;

    loop {
        line_buf.clear();
        match buf_reader.read_line(&mut line_buf) {
            Ok(0) => break,
            Ok(_) => lineno += 1,
            Err(_) => return Err(-1),
        }

        let raw = line_buf.trim_end_matches(&['\r', '\n'][..]);
        let raw_stripped = if lineno == 1 && raw.starts_with('\u{FEFF}') {
            &raw['\u{FEFF}'.len_utf8()..]
        } else {
            raw
        };

        let trimmed_start = raw_stripped.trim_start();
        let trimmed = trimmed_start.trim_end();

        if trimmed.chars().next().map_or(false, |c| config.start_comment_prefixes.contains(&c)) {
            continue;
        }

        if config.allow_multiline && !prev_name.is_empty() && !trimmed.is_empty() && raw_stripped.starts_with(|c: char| c.is_whitespace()) {
            let val = if config.allow_inline_comments {
                strip_inline_comment(trimmed_start, config.inline_comment_prefixes).trim_end()
            } else {
                trimmed
            };
            if !handler(&section, Some(&prev_name), Some(val), lineno) && error == 0 {
                error = lineno;
            }
        }
        else if trimmed.starts_with('[') {
            if let Some(close_idx) = trimmed[1..].find(']') {
                let sec_name = &trimmed[1..=close_idx];
                section = sec_name.to_string();
                prev_name.clear();
                if config.call_handler_on_new_section {
                    if !handler(&section, None, None, lineno) && error == 0 {
                        error = lineno;
                    }
                }
            } else if error == 0 {
                error = lineno;
            }
        }
        else if !trimmed.is_empty() {
            let delimiter = trimmed.find(|c| c == '=' || c == ':');
            if let Some(delim_idx) = delimiter {
                let name = trimmed[..delim_idx].trim_end();
                let mut value_part = trimmed[delim_idx + 1..].trim_start();
                if config.allow_inline_comments {
                    value_part = strip_inline_comment(value_part, config.inline_comment_prefixes).trim_end();
                }
                prev_name = name.to_string();
                if !handler(&section, Some(name), Some(value_part), lineno) && error == 0 {
                    error = lineno;
                }
            } else if config.allow_no_value {
                let name = trimmed;
                prev_name = name.to_string();
                if !handler(&section, Some(name), None, lineno) && error == 0 {
                    error = lineno;
                }
            } else if error == 0 {
                error = lineno;
            }
        }

        if config.stop_on_first_error && error != 0 {
            break;
        }
    }

    if error != 0 {
        Err(error)
    } else {
        Ok(())
    }
}

fn strip_inline_comment<'a>(s: &'a str, prefixes: &[char]) -> &'a str {
    let mut chars = s.char_indices().peekable();
    let mut was_space = false;
    while let Some((idx, ch)) = chars.next() {
        if was_space && prefixes.contains(&ch) {
            return s[..idx].trim_end();
        }
        was_space = ch.is_whitespace();
    }
    s
}

