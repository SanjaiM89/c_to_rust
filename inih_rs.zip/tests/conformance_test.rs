use inih_rs::*;
use std::collections::HashMap;

#[test]
fn test_basic_key_value() {
    let ini = "[user]\nname = Bob\nemail = bob@example.com\nage = 30";
    let mut map = HashMap::new();
    parse_string(ini, |sec, name, val, _| {
        if let (Some(n), Some(v)) = (name, val) {
            map.insert(format!("{}.{}", sec, n), v.to_string());
        }
        true
    }).unwrap();

    assert_eq!(map.get("user.name").unwrap(), "Bob");
    assert_eq!(map.get("user.email").unwrap(), "bob@example.com");
    assert_eq!(map.get("user.age").unwrap(), "30");
}

#[test]
fn test_colon_delimiter_and_inline_comments() {
    let ini = "[server]\nport: 8080 # default HTTP port\nhost: localhost ; local host";
    let mut map = HashMap::new();
    parse_string(ini, |sec, name, val, _| {
        if let (Some(n), Some(v)) = (name, val) {
            map.insert(format!("{}.{}", sec, n), v.to_string());
        }
        true
    }).unwrap();

    assert_eq!(map.get("server.port").unwrap(), "8080");
    assert_eq!(map.get("server.host").unwrap(), "localhost");
}

#[test]
fn test_multiline_continuation() {
    let ini = "[query]\nsql = SELECT *\n      FROM users\n      WHERE active = 1";
    let mut lines = Vec::new();
    parse_string(ini, |_sec, name, val, _| {
        if name == Some("sql") {
            if let Some(v) = val {
                lines.push(v.to_string());
            }
        }
        true
    }).unwrap();

    assert_eq!(lines, vec!["SELECT *", "FROM users", "WHERE active = 1"]);
}

#[test]
fn test_error_reporting() {
    let bad_ini = "[section\nkey = val";
    let err = parse_string(bad_ini, |_, _, _, _| true);
    assert!(err.is_err());
    assert_eq!(err.unwrap_err(), 1);
}

#[test]
fn test_upstream_normal_ini() {
    let path = "/tmp/c2rust_7vvaz3b3/source/tests/normal.ini";
    if std::path::Path::new(path).exists() {
        let mut count = 0;
        parse_file(path, |_, _, _, _| {
            count += 1;
            true
        }).unwrap();
        assert!(count > 0, "must parse pairs from normal.ini");
    }
}

#[test]
fn test_upstream_bom_ini() {
    let path = "/tmp/c2rust_7vvaz3b3/source/tests/bom.ini";
    if std::path::Path::new(path).exists() {
        let mut sections = Vec::new();
        parse_file(path, |sec, _, _, _| {
            if !sections.contains(&sec.to_string()) {
                sections.push(sec.to_string());
            }
            true
        }).unwrap();
        assert!(!sections.is_empty(), "must parse BOM ini");
    }
}
